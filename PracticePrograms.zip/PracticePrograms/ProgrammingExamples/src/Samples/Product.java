package Samples;

public class Product {
	int id;
	String name;
		
	//constructor
	Product(){
		id=0;
		name="";
	}
	//constructor with parameters (constructor overloading)
	Product(int pid,String pname){
		id=pid;
		name=pname;
	}
	
	void display() {
		System.out.println("id="+id+" name="+name);
	}
	
	public static void main(String[] args) {	
		//creating an object
		Product p=new Product();
		p.id=1;
		p.name="Laptop";
		p.display();
		
		//array
		Product prd[]=new Product[3];
		prd[0]=new Product(100,"Mobile");
		prd[1]=new Product(200,"Clothing");
		prd[2]=new Product(300,"Furniture-Chair");
		
		//enhanced for loop
		for(Product prod:prd) {
			prod.display();
		}
		
		//normal for loop
		for(int i=0;i<=2;i++) {
			prd[i].display();
		}
		
	}


}

package Samples;

public class MultiDimensionalArray {
	
	    public static void main(String[] args) {
	        float pincome[][] = new float[2][3]; 
	        pincome[0][0] = (float)5.8;
	        pincome[0][1] = (float)18.2;
	        pincome[0][2] = (float)5.18;
	        pincome[1][0] = (float)25.8;
	        pincome[1][1] = (float)16.4;
	        pincome[1][2] = (float)21.2;
	        print(pincome);
	        float[][] rincome=sort(pincome);
	        print(rincome);
	    }
	    
	   static float[][] sort (float[][] avalues){
	   	 int i,j,k;
	   	 for(i=0;i<avalues.length;i++) {
	   		 for(j=0;j<avalues[i].length-1;j++) {
	   			 for(k=0;k<avalues[i].length-j-1;k++) {
	   			 if(avalues[i][k]>avalues[i][k+1]) {
	   				 float temp=avalues[i][k];
	   				 avalues[i][k]=avalues[i][k+1];
	   				 avalues[i][k+1]=temp;
	   			 }
	   			
	   	}
	   	 }
	   	 
	    }  
	   	 System.out.println();
	   	return avalues;
	    }
	    
	    static void print (float[][] arr) {
	   	 for(int i=0;i<arr.length;i++) {
	   	 
	   		 for(int j=0;j<arr[0].length;j++) {
	   			 System.out.print(arr[i][j]+"\t");
	   		 }
	   		System.out.println();
	   	 }
	   
	    }
}


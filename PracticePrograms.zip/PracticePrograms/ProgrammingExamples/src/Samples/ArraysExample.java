package Samples;

public class ArraysExample {
	
	public static void main(String[] args) {
		
	}

}

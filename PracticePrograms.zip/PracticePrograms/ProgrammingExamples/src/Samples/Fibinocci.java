package Samples;

public class Fibinocci {

public static void main(String[] args) {
		// TODO Auto-generated method stub
	int a=0, b=1, c=0;
	System.out.print(a+ " ");
	for (int i=0;i<1000;i++) {
		a=b;
		b=c;
		c=a+b;
		if(c>1000) {
			break;
		}
		else {
		System.out.print(c+ " ");
		}
		}
	}

}

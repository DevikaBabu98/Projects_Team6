package Samples;

public class EvenOdd {
	
	public static void main(String[] args) {
		int num=11;
		if(num%2==0) {
			System.out.println(num+" is an even number");
		}
		else {
			System.out.println(num+" is an odd number");
		}
	}

}

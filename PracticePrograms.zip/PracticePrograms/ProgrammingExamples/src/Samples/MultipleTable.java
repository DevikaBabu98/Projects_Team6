package Samples;

public class MultipleTable {

	public static void main(String[] args) {
		int i, j;
		int m=1;
		for (i=1;i<=10;i++) {
			for(j=1;j<=10;j++) {
				m=i*j;
				System.out.println(i+" * "+j+" = "+m);
			}
		}
	}
}

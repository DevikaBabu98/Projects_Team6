package com.seleniumm.pomm;

import java.time.Duration;

import org.junit.jupiter.api.BeforeAll;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MainTestAppJUnit {
	
	@BeforeAll
	public static void main(String args[]) {
		
		// Set the path for the ChromeDriver
		System.setProperty("webdriver.chrome.driver",
						"C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		// Create a new instance of the Chrome driver
	    WebDriver driver = new ChromeDriver();
	    
	    //wait
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

	}

}

package com.excel.utils;

import java.io.FileInputStream;
import java.util.stream.*;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadUtils {

	private static Workbook wbook;
	private static Sheet sheet;

	// open excel file, workbook, sheet
	public static void init() {
		try {
			// open excel file
			FileInputStream fis = new FileInputStream("./testdata.xlsx");

			// create workbook
			wbook = new XSSFWorkbook(fis);

			// create sheet
			sheet = wbook.getSheetAt(0);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// read test data for Contact Form
	static Stream<Arguments> getContactFormData() {
		//invoke ExcelReadUtils method
		Stream<Arguments> contactdata = ExcelReadUtils.readContactFormData();
		return contactdata;
	}
	
	@ParameterizedTest
	@MethodSource("getContactFormData")
	public void checkContactForm(String name, String email, String details) {
		try {
			// Open the HTML page (replace with your actual URL)
			driver.get(
					"file:///D:\\GAMA Training\\PracticePrograms\\com.seleniumm.pomm\\src\\main\\resources\\Home.html");

			// create homepage instance
			HomePage homePage = new HomePage(driver);

			// on homepage click aboutlink
			ContactPage contactPage = homePage.gotoContactPage();

			// wait until About page is loaded
			wait.until(ExpectedConditions.titleContains("Contact"));

			contactPage.fillContactForm(name, email, details);
			Thread.sleep(2000);
			String message = contactPage.checkSubmission();
			assertTrue(message.contains("Mail Sent Successfully"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@AfterAll
	public static void tearDown() {
		if (driver != null) {
			driver.quit();
		}
	}
}

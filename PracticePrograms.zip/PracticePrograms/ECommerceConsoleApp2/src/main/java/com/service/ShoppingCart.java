package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.app.DatabaseConnectionImpl;

public class ShoppingCart{
	
	DatabaseConnectionImpl dconn=new DatabaseConnectionImpl();
	
	//adding Product
	public void addProduct(int product_id,int quantity) throws SQLException {
		Connection conn=dconn.getConnection();
	    PreparedStatement ps=conn.prepareStatement("Insert into cart(id,quantity) values (?,?)");
	    ps.setInt(1, product_id);
	    ps.setInt(2, quantity);
	    ps.executeUpdate();
	    dconn.closeConnection(conn);
	}
	
	//View Shopping Cart
	public void viewCart() throws SQLException{
		
			Connection conn=dconn.getConnection();
		    PreparedStatement ps=conn.prepareStatement("SELECT products.id, products.name, products.category, products.specifications, products.price, cart.quantity FROM products INNER JOIN cart ON products.id = cart.id");
		    ResultSet rs=ps.executeQuery();
		    boolean hasResults = false;  
		       while(rs.next()) {
		    	   
		    	    hasResults = true; // At least one row is found
		    		int product_id = rs.getInt("id");
					String product_name = rs.getString("name").trim();
					String product_category = rs.getString("category").trim();
					String product_specifications = rs.getString("specifications").trim();
					double price=rs.getDouble("Price");
					int quantity=rs.getInt("quantity");
					System.out.println("Product ID: "+product_id);
					System.out.println("Product Name: "+product_name);
					System.out.println("Product Category: "+product_category);
					System.out.println("Product Specifications: "+product_specifications);
					System.out.println("Product Price: "+price);
					System.out.println("Product Quantity: "+quantity);
					System.out.println();
		       }
		       if (!hasResults) {
		            System.out.println("Cart is empty");
		        }
		       dconn.closeConnection(conn);
				
	}	
	
	//Checkout
	public void checkout() throws SQLException {
		
		Connection conn=dconn.getConnection();
	    PreparedStatement ps=conn.prepareStatement("SELECT cart.id,cart.quantity,products.price FROM CART INNER JOIN Products on cart.id=products.id");
	    ResultSet rs=ps.executeQuery();
	    double total= 0;
	    boolean hasResults = false;  
	    while(rs.next()) {
	    	hasResults = true;  
	    	int pid=rs.getInt("id");
	    	int quantity=rs.getInt("quantity");
	    	double price=rs.getDouble("price");
	    	total=total+(price*quantity);   	   	
	    }
	    if (!hasResults) {
            System.out.println("No Products to checkout!!");
        }
	    else {
	    	System.out.println("Total Amount: "+total); 
	    	System.out.println("Checking out....");
	    	ps=conn.prepareStatement("DELETE FROM cart");
	    	ps.executeUpdate();
	    }
	    
	    dconn.closeConnection(conn);	    
		
	}
	
}	
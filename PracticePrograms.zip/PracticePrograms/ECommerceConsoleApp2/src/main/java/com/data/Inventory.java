package com.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.app.DatabaseConnectionImpl;
import com.app.Product;

public class Inventory {
	
	public List<Product> productList;
	
	DatabaseConnectionImpl dconn=new DatabaseConnectionImpl();
	
	//Searching Product using Product Name
	public List<Product> searchProducts(String productName) throws SQLException {
       List<Product> productList=new ArrayList<>();
       Connection conn=dconn.getConnection();
       PreparedStatement ps=conn.prepareStatement("select * from products where name like?");
       ps.setString(1, productName);
       ResultSet rs=ps.executeQuery();
       boolean hasResults = false;
       while(rs.next()) {
    	    hasResults = true; // At least one row is found
    	   	int product_id = rs.getInt("id");
			String product_name = rs.getString("name").trim();
			String product_category = rs.getString("category").trim();
			String product_specifications = rs.getString("specifications").trim();
			double price=rs.getDouble("Price");
			System.out.println("Product ID: "+product_id);
			System.out.println("Product Name: "+product_name);
			System.out.println("Product Category: "+product_category);
			System.out.println("Product Specifications: "+product_specifications);
			System.out.println("Product Price: "+price);
    	   
       }
       
       if (!hasResults) {
           System.out.println("No Products Found");
       }
       dconn.closeConnection(conn);
       return productList;
	}		
}
	


package com.seleniumm;

public class LocateByXPathLocatorEg {

}

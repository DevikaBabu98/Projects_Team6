package com.seleniumm;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class KeyboardActionsEg {

	public static void main(String[] args) throws InterruptedException{
		//chrome driver path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		//Create an instance of driver
		WebDriver driver = new ChromeDriver();

		//Load web page under Test
		driver.get("file:///D:\\GAMA Training\\PracticePrograms\\com.seleniumm\\src\\main\\resources\\KeyboardActions.html");
		
		
		WebElement inputField = driver.findElement(By.id("inputField"));
		inputField.sendKeys("Some text here!");
		
		Thread.sleep(2000);
		
		inputField.sendKeys(Keys.BACK_SPACE+""+Keys.BACK_SPACE);
		inputField.sendKeys(Keys.CONTROL+""+"A");
		System.out.println(inputField.getAttribute("value"));
		
		inputField.sendKeys(Keys.TAB);
		driver.findElement(By.id("submitButton")).sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		
		System.out.println(driver.findElement(By.id("output")).getText());
		Thread.sleep(5000);
		
		driver.quit();
	}	
	
}
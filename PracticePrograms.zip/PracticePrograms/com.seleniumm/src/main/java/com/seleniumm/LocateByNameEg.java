package com.seleniumm;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByNameEg {

	public static void main(String[] args) throws Exception {
		//chrome driver path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");
				
		//Create an instance of Chrome driver
		WebDriver driver = new ChromeDriver();
				
		//Load web page under Test
		driver.get("file:///D:\\GAMA Training\\PracticePrograms\\com.seleniumm\\src\\main\\resources\\LocateByName.html");
		
		//locate element by name
		WebElement usernameField=driver.findElement(By.name("username"));
		
		//
		usernameField.sendKeys("myusername");
		
		Thread.sleep(3000);
		
		driver.quit();
		
	}

}

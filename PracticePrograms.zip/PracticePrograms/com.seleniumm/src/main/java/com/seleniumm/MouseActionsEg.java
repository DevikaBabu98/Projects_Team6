package com.seleniumm;

import org.openqa.selenium.By;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class MouseActionsEg {
	
public static void main(String[] args) throws Exception{
	//chrome driver path
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

	//Create an instance of driver
	WebDriver driver = new ChromeDriver();

	//Load web page under Test
	driver.get("file:///D:\\GAMA Training\\PracticePrograms\\com.seleniumm\\src\\main\\resources\\MouseAction.html");
	
	Actions actions = new Actions(driver);
	WebElement clickButton = driver.findElement(By.id("clickButton"));
	
	//Perform Click
	//clickButton.click();
	actions.click(clickButton).perform();
	
	Thread.sleep(2000);

	WebElement hoverDiv = driver.findElement(By.id("hoverDiv"));
	//on mouse over
	actions.moveToElement(hoverDiv).perform();
	
	Thread.sleep(3000);
	
	//Double click
	WebElement doubleClickButton = driver.findElement(By.id("doubleClickButton"));
	
	actions.doubleClick(doubleClickButton).perform();
	Thread.sleep(3000);
	
	//right click
	actions.contextClick(clickButton).perform();
	Thread.sleep(3000);
	
	
	WebElement dragDiv = driver.findElement(By.id("dragDiv"));
	
	WebElement dropArea = driver.findElement(By.id("dropArea"));
	
	//drag and drop
	actions.clickAndHold(dragDiv).moveToElement(dropArea).release().perform();
	
	Thread.sleep(2000);
	
	driver.quit();
	
	}
}
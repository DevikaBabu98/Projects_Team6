package com.seleniumm;

import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByCSSEg {

	public static void main(String[] args) throws Exception{
		//chrome driver path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		//Create an instance of driver
		WebDriver driver = new ChromeDriver();

		//Load web page under Test
		driver.get("file:///D:\\GAMA Training\\PracticePrograms\\com.seleniumm\\src\\main\\resources\\LocateByCSS.html");
		
		//NoSuchElementException
		
		//CSSSelector by Class
		//WebElement element = driver.findElement(By.cssSelector(".input-field"));
		//WebElement element = driver.findElement(By.cssSelector("input.input-field"));

		//CSSSelector by Id
		//WebElement element = driver.findElement(By.cssSelector("input#some-id"));

		//CSS Selector with Attribute "input[type='email']"
		//WebElement element = driver.findElement(By.cssSelector("input[type='password']"));

		//CSS Selector using Parent child elements
		WebElement element = driver.findElement(By.cssSelector("form input"));
		element.sendKeys("somepassword");
		
		System.out.println(element.getAttribute("value"));

		//CSS Selector using OR
				
		List<WebElement> elements = driver.findElements(By.cssSelector("input#some-id, .input-field"));
		
		elements.stream().forEach((e) -> { 
			System.out.println("-->" + e.getAttribute("type"));
		});
		
		//CSS Selector using AND		
		
		List<WebElement> elementa = driver.findElements(By.cssSelector("input#some-id.input-field"));
		
		System.out.println(elementa.getTagName() + " " + elementa.getAttribute("type"));
	

		Thread.sleep(6000);
		driver.quit();
	}
		
}

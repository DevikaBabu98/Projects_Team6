package com.seleniumm;

public class LocateByTagMultipleElementsEg {

}

package com.seleniumm;

import java.time.Duration;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByClassEg {

	public static void main(String[] args) throws Exception{
		//chrome driver path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		//Create an instance of driver
		WebDriver driver = new ChromeDriver();

		//Load web page under Test
		driver.get("file:///D:\\GAMA Training\\PracticePrograms\\com.seleniumm\\src\\main\\resources\\LocateByClassEg.html");
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		WebElement button = wait.until(ExpectedConditions.elementToBeClickable(By.className("button")));

		button.click();
		
		WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("message")));

		System.out.println("Message: "+message.getText());
		
		Thread.sleep(10000);
		
		driver.quit();
		
	}
}

package com.seleniumm;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertConfirmPopupEg {

	public static void main(String[] args) throws InterruptedException{
		//chrome driver path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		//Create an instance of driver
		WebDriver driver = new ChromeDriver();

		//Load web page under Test
		driver.get("file:///D:\\GAMA Training\\PracticePrograms\\com.seleniumm\\src\\main\\resources\\AlertConfirmEg.html");
		
		//test Confirm
		testConfirm(driver);
		
		//test Alert
		testAlert(driver);
		
		//test Prompt
		testPrompt(driver);
		
		driver.quit();
	}


	private static void testAlert(WebDriver driver) throws InterruptedException{
		WebElement alertButton = driver.findElement(By.xpath("//button[text()='Show Alert']"));

		alertButton.click();

		Thread.sleep(2000);
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		alert.accept();

		Thread.sleep(2000);

	}

	private static void testConfirm(WebDriver driver) throws InterruptedException{
		WebElement confirmButton = driver.findElement(By.xpath("//button[text()='Show Confirm']"));

		confirmButton.click();

		Thread.sleep(2000);
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		alert.accept();

		Thread.sleep(2000);

	}


	private static void testPrompt(WebDriver driver) throws InterruptedException {
		
		//WebElement promptButton = driver.findElement(By.xpath("//button[text()='Show Prompt']"));
		WebElement promptButton = driver.findElement(By.id("prompt"));
		promptButton.click();
		
		Thread.sleep(2000);
		Alert alert = driver.switchTo().alert();
		System.out.println(alert.getText());
		alert.sendKeys("some name");
		
		alert.accept();
		
		Thread.sleep(2000);
		
     }

}
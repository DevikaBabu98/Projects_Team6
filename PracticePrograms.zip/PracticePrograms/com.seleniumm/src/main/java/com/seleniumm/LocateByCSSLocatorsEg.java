package com.seleniumm;

public class LocateByCSSLocatorsEg {

}

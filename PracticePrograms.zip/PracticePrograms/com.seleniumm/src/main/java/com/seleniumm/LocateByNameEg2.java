package com.seleniumm;

import java.time.Duration;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByNameEg2 {
public static void main(String[] args) throws Exception{
	//chrome driver path
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

	//Create an instance of driver
	WebDriver driver = new ChromeDriver();

	//Load web page under Test
	driver.get("file:///D:\\GAMA Training\\PracticePrograms\\com.seleniumm\\src\\main\\resources\\LocateByNameEg2.html");
	
	//create WebDriverWait
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	
	//locate username, only after it appears on webpage
	WebElement usernameField = wait.until(ExpectedConditions
			.visibilityOfElementLocated(By.name("username")));
	
	//enter text in username field
	usernameField.sendKeys("someuser");
	
	//locate age
	WebElement ageField = driver.findElement(By.name("age"));
	
	//enter age
	ageField.sendKeys(String.valueOf(35));
	
	//set country
	WebElement countryDropdown = driver.findElement(By.name("country"));
	countryDropdown.sendKeys("Canada");
	
	//locate button
	WebElement submitButton = driver.findElement(By.id("submitButton"));
	
	//click button
	submitButton.click();
	
	//wait for message to be visible & get updated message text
	WebElement messageDiv = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("message")));
	System.out.println("Message is:"+messageDiv.getText());

	Thread.sleep(10000);
	
	driver.quit();
}
}
package com.example.demo_resttemplate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class DemoResttemplateApplicationTests {

	@Autowired
	private MockMvc mockMvc;
	
	@Test
	void testGetTicket() throws Exception {
		mockMvc.perform(get("/redbus/8"))
				.andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.fromplace").value("pqrs"))
				.andExpect(jsonPath("$.toPlace").value("mnop"));
	}
	
	@Test
	void testBookTicket() throws Exception{
		mockMvc.perform(post("/redbus")
				.contentType(MediaType.APPLICATION_JSON)
				.content(
				"{\"username\":\"user456\","
				+ "{\"fromplace\":\"tuvw\","
				+ "\"toplace\":\"klmn\","
				+ "\"email\":\"987652@gmail.com\","
				+ "\"price\":9876.5}"))
				.andExpect(status().isCreated())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.username").value("user456"));
	}
	
	@Test
	void testUpdateTicket() throws Exception{
		mockMvc.perform(put("/redbus")
				.contentType(MediaType.APPLICATION_JSON)
				.content(
				//"{\"username\":\"user456\","+
				"{\"fromplace\":\"jjjj\","
				+ "\"toplace\":\"klmn\","
				+ "\"email\":\"987652@gmail.com\","
				+ "\"price\":9876.5}"))
				.andExpect(status().isCreated())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.username").value("user456"));
	}
	
	@Test
	void cancelTicket() throws Exception{
		mockMvc.perform(delete("/redbus/27"))
				.andExpect(status().isOk());
	}

}

package Projects;


public class DebugExample{
	public static void main(String[] args) {	
		ShoppingCarts scart= new ShoppingCarts();
		System.out.println("Total number of existing products: "+Products.get_num_prods());
		Products p1=new Products(100, "Mobile");
		scart.addProduct(p1);
		Products p2=new Products(200, "Clothing");
		scart.addProduct(p2);
		scart.listProducts();
		scart.emptyCart();
	
	}
}

class ShoppingCarts {
	Products aprod[];
	int cindex;
	
	
	//constructor
	ShoppingCarts(){
		aprod=new Products[5];		
	}
	
	//member methods
	//add Product
	Products addProduct(Products prod) {
		aprod[cindex]=prod;
		cindex++;	
		System.out.println("Added product with id "+prod.id);
		return prod;
	}
	
	//list products
	void listProducts() {
		for(int i=0;i<cindex;i++) {
			aprod[i].display();
		}		
	}
	//Empty cart
	void emptyCart(){
		aprod=new Products[5];
		cindex=0;
		System.out.println("Deleted all items from cart");
	}
	
}

class Products{
	int id;
	String name;
	static int num_of_prods=100;
	
	//constructor
	Products(){
		id=0;
		name="";
	}
	//constructor with parameters
	Products(int pid,String pname){
		id=pid;
		name=pname;
	}
	
	static int get_num_prods() {
		return num_of_prods;
	}

	void display() {
		System.out.println("id="+id+" name="+name+" Total no.of products"+num_of_prods);
	}
	
}


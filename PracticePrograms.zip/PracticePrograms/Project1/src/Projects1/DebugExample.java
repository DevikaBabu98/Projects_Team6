package Projects1;

import Projects1.Product;
import Projects1.ShoppingCart;

public class DebugExample {
	
		public static void main(String[] args) {	
			ShoppingCart scart= new ShoppingCart();
			System.out.println("Total number of existing products: "+Product.get_num_prods());
			Product p1=new Product(100, "Mobile");
			scart.addProduct(p1);
			Product p2=new Product(200, "Clothing");
			scart.addProduct(p2);
			scart.listProducts();
			scart.emptyCart();
			
}
}

package Projects1;

public class Product {
	private int id;
	private String name;
	private static int num_of_prods=100;
	
	//constructor
	private Product(){
		id=0;
		name="";
	}
	//constructor with parameters (constructor overloading)
	Product(int pid,String pname){
		id=pid;
		name=pname;
	}
	
	public int getId() {
		return id;
	}
	
	//this - current object
	public void setId(int id) {
		this.id=id;
	}
	public String getName() {
		return name;
	}
	
	//this - current object
	public void setName(String name) {
		this.name=name;
	}
	
	static int get_num_prods() {
		return num_of_prods;
	}
	void display() {
		System.out.println("id="+id+" name="+name+" Total no.of products: "+num_of_prods);
	}
	
	@Override
	public boolean equals(Object obj) {
		if(this==obj) {
			return true;
		}
		if((obj==null)||(getClass()!=obj.getClass())) {
			return false;
		}
		Product product=(Product)obj;
		return id==product.id;
		
	}
}

package com.finalEg;

public class FinalDemo {
	
	//final data member
	final int n=10;
	final String name;
	
	//Constructor
	public FinalDemo(String name) {
		super();
		this.name = name;
	}
	
	public void demoFinal() {
		//final local variable
		final int x;
		x=30;
		System.out.println("Final local variable x:"+x);
	}
	
	public static void main(String[] args) {
		FinalDemo demo=new FinalDemo("Final");
		System.out.println("Final Data member n: " +demo.n);
		System.out.println("Final Data member name: "+demo.name);
		demo.demoFinal();
	}

	

}

package com.p7;

class A{

static void met(){
System.out.println("A.met()");
}

}

class B extends A{

}
//---------------------
public class MainProgram{
	public static void main(String args[]){
		B obj = new B();
		obj.met();
	}
}



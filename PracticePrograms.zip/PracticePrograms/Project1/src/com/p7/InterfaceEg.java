package com.p7;

interface Circle{
	double PI = 3.14;
	double getSurfaceArea(double radius);
	double getCircumference(double radius);
}

class CircleImpl implements Circle{

	@Override
	public double getSurfaceArea(double radius) {
		return 2*PI*radius;
	}

	@Override
	public double getCircumference(double radius) {
		return PI*radius;
	}
	
}


public class InterfaceEg {


}


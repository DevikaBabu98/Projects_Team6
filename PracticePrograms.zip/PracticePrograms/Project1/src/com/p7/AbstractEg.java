package com.p7;

abstract class Animal{
	String name;
	abstract void move(); 
	
	void eat() {
		//method body
	}

	public Animal(String name) {
		super();
		this.name = name;
	}

	abstract void display();
	
}

//Concrete class
class Snake extends Animal{
	
	public Snake(String name) {
		super(name);
	}

	@Override
	void move() {
		System.out.println("Crawling");
		
	}
	void display() {
		System.out.println(name);
	}
}

public class AbstractEg {
	
	public static void main(String[] args) {
		Animal obj=new Snake("Cobra");
		obj.move();
		obj.display();
	}

}

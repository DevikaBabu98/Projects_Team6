package com.p7;

class Vehicle{
	String brand;
	
	public Vehicle(String brand) {
		this.brand=brand;
	}
	
	void honk() {
		System.out.println("Vehicle is honking");
	}
}

class Car extends Vehicle{
	public Car(String brand) {
		super(brand);
	}
	
	void honk() {
		System.out.println("Car is honking");     
	}
}

class Truck extends Vehicle{

	public Truck(String brand) {
		super(brand);
	}
	void honk() {
		System.out.println("Truck is honking");     
	}
}
//resolved the null pointer error
public class VehicleMgr {

	public static void main(String[] args) {
		
	  Vehicle[] vehicles= new Vehicle[3];
	  
	  //Store objects of derived classes in array
      vehicles[0] = new Vehicle("Honda");
      vehicles[1]=new Car("Kia");
      vehicles[3]=new Truck("Ford");
      
      
      for(Vehicle vehicle:vehicles) {
    	  vehicle.honk();
      }
 
}

}
package com.p7;

//inheritance is is-a relation
class Product{
	int id;
	String name;
	
	void display() {
		System.out.println("Product.display()");
	}
}

class ElectronicProduct extends Product{
	float voltage;
	void display() {
		System.out.println("ElectronicProduct.display()");
	}
}
public class MethodOverrideEg {

	public static void main(String[] args) {
		
		Product obj=new ElectronicProduct();
		/*Method overriding
		* Dynamic polymorphism-run time decision
		*/
		obj.display();//display of derived
	}
}

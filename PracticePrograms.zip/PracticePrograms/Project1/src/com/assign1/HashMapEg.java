package com.assign1;

import java.util.HashMap;

public class HashMapEg {
	
	public static void main(String[] args) {
		HashMap<String,Boolean> hm=new HashMap<>();
		
		hm.put("ggggg", true);
		hm.put("ggreggegg", true);
		hm.put("dfdfd", true);
		hm.put("gggg", true);
		hm.put("srssdfsdf", true);
		hm.put("ssdfdfeer", true);
		
		//Using forEach correctly to print keys
		hm.keySet().stream().forEach(key->System.out.println(key));
	}

}

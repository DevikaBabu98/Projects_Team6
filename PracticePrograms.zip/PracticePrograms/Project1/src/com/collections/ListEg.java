package com.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

class City{
	private String name;
	private long pincode;
	private String state;
	
	//constructor
	public City(String name, long pincode, String capital_city) {
		this.name = name;
		this.pincode = pincode;
		this.state = capital_city;
	}
	
	//getter, setter - TBD
	
	//toString
	@Override
	public String toString() {
		return "City [name=" + name + ", pincode=" + pincode + ", capital_city=" + state + "]";
	}
}

public class ListEg {

	public static void main(String[] args) {
		// create list
		List<City> cities=new ArrayList<City>();
		Scanner sc=new Scanner(System.in);
		//add City objects to list
		cities.add(new City("city1",1234,"capital1"));
		cities.add(new City("city2",3456,"capital2"));
		
		System.out.println("Please enter city name");
		String icity =sc.next();
		
		System.out.println("Please enter pincode");
		long ipincode=sc.nextLong();
		
		System.out.println("Please enter state");
		String istate=sc.next();
		
		cities.add(new City(icity,ipincode,istate));
		
		display(cities, "Before reversing");
		Collections.reverse(cities);
		
		display(cities, "After reversing");
		
		

	}
	
	private static void display(List<City> lcity,String msg) {
		System.out.println(msg);
		//iterate and display
		Iterator<City> itr=lcity.iterator();
			
			while(itr.hasNext()) {
				System.out.println(itr.next());
			}
			System.out.println();

}
}

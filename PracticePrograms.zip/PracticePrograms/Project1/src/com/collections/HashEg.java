package com.collections;

import java.util.HashSet;

public class HashEg {

	public static void main(String[] args) {
		
		HashSet<City> hss=new HashSet<>();
			
		hss.add(new City("city1",1234,"capital1"));
		hss.add(new City("city2",4567,"captial2"));
		hss.add(new City("city1",1234,"capital1"));
		hss.add(new City("city3",654321,"captial3"));
		
		
		for(City element:hss) {
			System.out.println(element+"\t");
		}
		/*HashSet<String> hss=new HashSet<>();
		
		hss.add("cccccc");
		hss.add("aaaaaaa");
		hss.add("ffgfhgjjkkl");
		hss.add("bbbbbbb");
		hss.add("aaaaaa");
		
		for (String element: hss) {
			System.out.println(element+"\t");
		}*/

	}

}

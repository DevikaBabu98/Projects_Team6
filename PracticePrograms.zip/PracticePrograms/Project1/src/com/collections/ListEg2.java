package com.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

class Cities{
	private String name;
	private long pincode;
	private String state;
	
	//constructor
	public Cities(String name, long pincode, String capital_city) {
		this.name = name;
		this.pincode = pincode;
		this.state = capital_city;
	}
	
	//getter, setter - TBD
	
	//toString
	@Override
	public String toString() {
		return "City [name=" + name + ", pincode=" + pincode + ", capital_city=" + state + "]";
	}
}

public class ListEg2 {

	public static void main(String[] args) {
		// create list
		List<Cities> cities=new ArrayList<Cities>();
		Scanner sc=new Scanner(System.in);
		//add Cities objects to list
		cities.add(new Cities("city1",1234,"capital1"));
		cities.add(new Cities("city2",3456,"capital2"));
		
		System.out.println("Please enter city name");
		String icity =sc.next();
		
		System.out.println("Please enter pincode");
		long ipincode=sc.nextLong();
		
		System.out.println("Please enter state");
		String istate=sc.next();
		
		cities.add(new Cities(icity,ipincode,istate));
		
		cities.add(new Cities("city3",2451,"capital3"));
		
		//iterate and display
		Iterator<Cities> itr=cities.iterator();
		
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}

package com.collections;

//Generic class
class Wrapper<T> {
	T data;

	// setter
	void setData(T data) {
		this.data = data;
	}

	// getter
	T getData() {
		return data;
	}
}

public class GenericsEg {
	public static void main(String[] args) {
		Wrapper<String> ws = new Wrapper<>();
		Wrapper<Integer> wi=new Wrapper<>();
		
		Integer oi=new Integer(21);
		
		String str="25";
		int val=Integer.parseInt(str);
		//...
	
		Wrapper<City> wc = new Wrapper<City>();
		//...
}
}


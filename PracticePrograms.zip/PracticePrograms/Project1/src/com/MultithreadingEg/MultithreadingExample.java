package com.MultithreadingEg;

class PrintOdd1 extends Thread {

	
	@Override
	public void run() {
		try{
			String str="Child Thread";
			for (int i = 0; i < str.length(); i += 1) {
				char ch=str.charAt(i);
				System.out.println("Child Thread: " +ch);
				Thread.sleep(30);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
public class MultithreadingExample {

	
	public static void main(String[] args) {
		try{
			PrintOdd1 thread = new PrintOdd1();
			
			thread.start();
			
			String str="Main Thread";
			for (int i = 0; i < str.length(); i += 1) {
				char ch=str.charAt(i);
				System.out.println("Main Thread: "+ch);
			
				Thread.sleep(25);
			}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
	}


	



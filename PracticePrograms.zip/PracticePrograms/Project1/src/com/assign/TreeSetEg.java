package com.assign;

import java.util.Collections.*;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.TreeSet;

class Country{
	private String name;
	private double gdp;
	
	public Country(String name, double gdp) {
		this.name = name;
		this.gdp = gdp;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getGdp() {
		return gdp;
	}
	public void setGdp(double gdp) {
		this.gdp = gdp;
	}
	
	@Override
	public String toString() {
		return "Country [name = "+name+", gdp = "+gdp+ "]";
	}
		
}

public class TreeSetEg {

	public static void main(String[] args) {
		
		//Lamda Expression
		TreeSet<Country> tss=new TreeSet<Country>(
				(ctry1,ctry2)->ctry1.getName().compareTo(ctry2.getName())//sorting order by name
				);
				
		tss.add(new Country("name1",2345.4));
		tss.add(new Country("name3",3564.5));
		tss.add(new Country("name2",4675.8));
		tss.add(new Country("name4",3342.9));
		
		Iterator<Country> itrs=tss.iterator();
		System.out.println("Sorted order by Country Names");
		for(;itrs.hasNext();) {
			System.out.println(itrs.next());
		}
	
		//Minimum element in Countries
		Country cmin=Collections.min(tss,(ctry1,ctry2)->ctry1.getName().compareTo(ctry2.getName()));
		System.out.println("\nMinimum Element: "+cmin);
		
		//Maximum element in countries
		Country cmax=Collections.max(tss,(ctry1,ctry2)->ctry1.getName().compareTo(ctry2.getName()));
		System.out.println("\nMaximum Element: "+cmax);	

	}


}

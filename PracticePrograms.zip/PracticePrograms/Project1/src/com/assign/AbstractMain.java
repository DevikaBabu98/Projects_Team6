package com.assign;

abstract class Vehicle{
	void start() {
		System.out.println("Vehicle is starting");
	}
	
	void stop() {
		System.out.println("Vehicle is stopping");
	}
}


class Car extends Vehicle{
	void drive() {
		System.out.println("Car is driving");
	}
}
public class AbstractMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car car=new Car();
		car.start();
		car.drive();
		car.stop();
		

	}

}

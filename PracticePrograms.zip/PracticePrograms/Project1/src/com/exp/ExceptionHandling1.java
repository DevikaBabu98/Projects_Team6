package com.exp;
 
public class ExceptionHandling1 {
	public static void main(String[] args){
	try {
		met();
	}
	catch(Exception ie) {
		System.out.println("Invalid Exception occured");
		}
	}
}

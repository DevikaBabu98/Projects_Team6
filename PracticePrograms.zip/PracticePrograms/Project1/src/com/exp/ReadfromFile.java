package com.exp;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ReadfromFile {

	public static void main(String[] args) throws Exception {
		FileReader fis=new FileReader("./xyz.txt");
		
		int c;
		
		while((c==fis.read()) != -1) {
			System.out.println((char) c);
		}
		fis.close();
	}

}

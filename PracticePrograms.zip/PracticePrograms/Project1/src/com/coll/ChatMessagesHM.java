package com.coll;

import java.util.HashMap;

public class ChatMessagesHM {

	public static void main(String[] args) {
		HashMap<String, String> hmss=new HashMap<>();
		
		hmss.put("name1","msg99");
		hmss.put("name3", "msg199");
		hmss.put("name2","mssg499");
		hmss.put("name6", "mssg3213");
		
		
		
	}
	
}

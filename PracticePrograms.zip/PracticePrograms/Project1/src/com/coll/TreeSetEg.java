package com.coll;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

class Country{
	private String name;
	private double gdp;
	
	public Country(String name, double gdp) {
		super();
		this.name = name;
		this.gdp = gdp;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getGdp() {
		return gdp;
	}
	public void setGdp(double gdp) {
		this.gdp = gdp;
	}
	
	@Override
	public String toString() {
		return "Country [name = "+name+", gdp = "+gdp+ "]";
	}
	
}

public class TreeSetEg {

	public static void main(String[] args) {
		
		//creating comparator class inside a class without a class name
		//Anonymous inner class
//		/*Comparator<Country> cc=new Comparator<Country>() {
//			@Override
//			public int compare(Country ctry1,Country ctry2) {
//				return (int)(ctry2.getGdp()-ctry1.getGdp());
//			}
//		};*/
//		
		//Lamda Expression
		TreeSet<Country> tss=new TreeSet<Country>(
				//(ctry1,ctry2)->{return (int)(ctry1.getGdp()-ctry2.getGdp());});
				(ctry1,ctry2)->(int)(ctry1.getGdp()-ctry2.getGdp()));
	
		tss.add(new Country("name1",2345.4));
		tss.add(new Country("nmae2",3564.5));
		tss.add(new Country("name3",4675.8));
		tss.add(new Country("name4",3342.9));
		
		Iterator<Country> itrs=tss.iterator();
		
		for(;itrs.hasNext();) {
			System.out.println(itrs.next());
		}
		
	

}


	
	
	/*@Override
	public int compare(String str1, String str2) {
		//return str1.compareTo(str2);//ascending order
		return str2.compareTo(str1);//descending order
	}*/
}

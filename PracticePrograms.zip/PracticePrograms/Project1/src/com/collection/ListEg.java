package com.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

class City{
	private String name;
	private long pincode;
	private String state;
	
	//constructor
	public City(String name, long pincode, String capital_city) {
		this.name = name;
		this.pincode = pincode;
		this.state = capital_city;
	}
	
	//getter, setter
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	//toString
	@Override
	public String toString() {
		return "City [name=" + name + ", pincode=" + pincode + ", capital_city=" + state + "]";
	}
	
	

	
}

public class ListEg {

	public static void main(String[] args) {
		// create list
		List<City> cities=new ArrayList<City>();
		System.out.println("Enter no.of cities");
		Scanner sc=new Scanner(System.in);
		int num= sc.nextInt();
		//add City objects to list
		
		for(int i=0;i<num;i++) {
			System.out.println("Please enter city name");
			String icity =sc.next();
			
			System.out.println("Please enter pincode");
			long ipincode=sc.nextLong();
			
			System.out.println("Please enter state");
			String istate=sc.next();
			
			cities.add(new City(icity,ipincode,istate));
			
			
		}
		//cities.add(new City("city1",1234,"capital1"));
		//cities.add(new City("city2",3456,"capital2"));
		
		
		//iterate and display
		/*Iterator<City> itr=cities.iterator();
		
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}*/
		
		
		//Enhanced for loop for displaying cities
		for(City c:cities) {
			System.out.println(c);
		}
		
		//normal for loop for displaying cities
		for(int i=0;i<num;i++) {
			System.out.println(cities.get(i));
			
		}
		
		//Removing a city
		System.out.println("Enter name of city to remove");
		String removeCity=sc.next();
		boolean removed=false;
		for(City c: cities) {
			if(c.getName().equalsIgnoreCase(removeCity)) {
				cities.remove(c);
				removed=true;
				break;
			}
		}
		if(removed) {
			System.out.println("City removed successfully");
		}else {
			System.out.println("City not found");
		}
		System.out.println("Cities after removal");
		for(City c:cities) {
			System.out.println(c);
		}

	}

}

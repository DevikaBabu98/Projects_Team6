package com.collection;

public class ListMin {

}

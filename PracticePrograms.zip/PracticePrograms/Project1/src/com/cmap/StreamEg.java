package com.cmap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StreamEg {

	public static void main(String[] args) {
		
		List<Integer> list=Arrays.asList(3,4,15,6,12,20);
		ArrayList<Integer> alist=new ArrayList<>(list);
		/*list.stream().filter((e) -> e>10).forEach((e)->{
			System.out.println(e);
		});*/
		

	}

}

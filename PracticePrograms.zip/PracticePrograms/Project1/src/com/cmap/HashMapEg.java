package com.cmap;

import java.util.*;
import java.util.Map.Entry;


class State {
	private String name;
	private long population;

	public State(String name, long population) {
		super();
		this.name = name;
		this.population = population;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPopulation() {
		return population;
	}

	public void setPopulation(long population) {
		this.population = population;
	}

	@Override
	public String toString() {
		return "State [name=" + name + ", population=" + population + "]";
	}
}

class City {
	private String name;
	private double total_area;

	public City(String name, double total_area) {
		super();
		this.name = name;
		this.total_area = total_area;
	}

	@Override
	public String toString() {
		return "City [name=" + name + ", total_area=" + total_area + "]";
	}
}

public class HashMapEg {
	public static void main(String[] args) {
		
	
		HashMap<State,City> hmss = new HashMap<>(new MyComparator());
		hmss.put(new State("Karnataka",2432), new City("Bangalore",1421));
		hmss.put(new State("Tamil Nadu",5432), new City("Chennai",5428));
		hmss.put(new State("Kerala",1439), new City("Trivandrum",1231));

		Set<Entry<State, City>> sess = hmss.entrySet();
		Iterator<Entry<State, City>> iess = sess.iterator();

		while (iess.hasNext()) {
			Entry<State, City> ess = iess.next();
			System.out.println(ess.getKey() + "->" + ess.getValue());
		}

	}
}

class MyComparator implements Comparator<State>{
	
	@Override
	public int compare(State s1,State s2) {
		long v1=(long)hmss.get(s1);
		return (int)(s2.getPopulation()-s1.getPopulation());
	}
}
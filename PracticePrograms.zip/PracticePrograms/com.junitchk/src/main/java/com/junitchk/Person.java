package com.junitchk;

public class Person {

}

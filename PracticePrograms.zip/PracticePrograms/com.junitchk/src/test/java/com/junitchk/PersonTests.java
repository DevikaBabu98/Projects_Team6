package com.junitchk;

public class PersonTests {

	private Person person;
	
	@BeforeEach
	void metbe() {
		person = new Person("name1",34,10000);
	}
	
	
}

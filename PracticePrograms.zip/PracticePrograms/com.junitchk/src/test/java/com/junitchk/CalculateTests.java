package com.junitchk;

public class CalculateTests {

}

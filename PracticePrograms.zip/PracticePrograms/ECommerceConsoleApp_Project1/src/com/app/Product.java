package com.app;

public class Product {
	private int product_id;
	String product_name;
	String product_category;
	String product_specifications;
	private double price;
	
	
	public Product(int product_id, String product_name, String product_category, String product_specifications,
			double price) {
		super();
		this.setProduct_id(product_id);
		this.product_name = product_name;
		this.product_category = product_category;
		this.product_specifications = product_specifications;
		this.setPrice(price);
	}

	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getProduct_id() {
		return product_id;
	}


	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_category() {
		return product_category;
	}

	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}

	public String getProduct_specifications() {
		return product_specifications;
	}

	public void setProduct_specifications(String product_specifications) {
		this.product_specifications = product_specifications;
	}
	
	
}

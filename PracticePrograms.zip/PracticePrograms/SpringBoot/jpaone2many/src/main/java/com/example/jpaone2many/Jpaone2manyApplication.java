package com.example.jpaone2many;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jpaone2manyApplication {

	public static void main(String[] args) {
		SpringApplication.run(Jpaone2manyApplication.class, args);
	}

}

package com.example.jpaone2many.control;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {

}

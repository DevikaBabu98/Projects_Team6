package com.example.demo_ticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}

package testrun;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
/*
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
*/
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(publish = true,
    features = "src/test/resources/features/simpleFeature.feature", // Path to feature files
    glue = "stepdefinitions" ,                // Path to step definition classes
    plugin = {"pretty"}                       // To get a readable output
)
public class RunnerTest {
	/*public RunnerTest() {
		System.out.println("Hello");
	}
	
	@BeforeAll
	public static void met() {
		System.out.println("ksjhfksd");
	}
	
	@Test
	public void met1() {
		System.out.println("nskdjfsd");
	}*/
}

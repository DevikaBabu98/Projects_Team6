package runner;

import static org.junit.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

public class GoogleSearchSteps {
	WebDriver driver;

	@Given("I am on the Google search page")
	public void i_am_on_the_google_search_page() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");

		// Create a new instance of the Chrome driver
		driver = new ChromeDriver();
		driver.get("https://www.google.com"); // Open Google home page
	}

	@When("I search for {string}")
	public void i_search_for(String searchQuery) {
		WebElement searchBox = driver.findElement(By.name("q")); // Locate the search input box by its 'name' attribute
		searchBox.sendKeys(searchQuery); // Type the search term into the search box
		searchBox.submit(); // Submit the search (equivalent to pressing Enter)
	}

	@Then("I should see search results related to {string}")
	public void i_should_see_search_results_related_to(String expectedText) {
		try {
			Thread.sleep(2000); // Simple wait, ideally use WebDriverWait for better synchronization
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// Find the element showing search result stats and check that it contains the
		// expected text
		WebElement resultStats = driver.findElement(By.id("result-stats"));
		String resultStatsText = resultStats.getText();

		// Assert that the search result contains the expected term (Cucumber or BDD)
		assertTrue(resultStatsText.contains(expectedText));

		driver.quit(); // Close the browser after the test
	}
}

package runner;
/*
import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
public class TestRunner {
    // The @Cucumber annotation is sufficient to run the Cucumber tests with JUnit 5.
	public TestRunner() {}
}*/

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(publish = true
)
public class TestRunner {
}



// Java code for Stream filter 
// (Predicate predicate) to get a stream 
// consisting of the elements of this 
// stream that match the given predicate. 
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream; 

public class FilterStreamEg { 

	// Driver code 
	public static void main(String[] args) 
	{ 

		// Creating a list of Integers 
		List<Integer> list = Arrays.asList(3, 4, 15, 6, 12, 20); 

		// Using Stream filter(Predicate predicate) 
		// to get a stream consisting of the 
		// elements that are divisible by 5 
		//filter(), map(), reduce()
		//Predicate
		list.stream().filter((num) -> {return num % 5 == 0;}).filter((num) -> {return num % 10 == 0;})
		.forEach(System.out::println); 
	
		System.out.println("---------------------------");
		//method 2
		//above can be split into two statements as well
		Stream<Integer> strm = list.stream().filter((num) -> {return num % 5 == 0;});
		strm.forEach(System.out::println); 
		
		//method 3
		List<Integer> list5 = list.stream().filter((num) -> {return num % 5 == 0;}).collect(Collectors.toList());
		list5.forEach(System.out::println); 
	} 
} 

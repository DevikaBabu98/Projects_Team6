package com.seleniumeg_pom;

import org.openqa.selenium.WebDriver;

public class DashboardPage {
    private WebDriver driver;

    // Constructor
    public DashboardPage(WebDriver driver) {
        this.driver = driver;
    }

    // Actions
    public String getDashboardTitle() {
        return driver.getTitle();
    }
}


package com.seleniumeg_pom;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class LoginTest {
    private WebDriver driver;
    private LoginPage loginPage;
    private DashboardPage dashboardPage;

    @BeforeEach
    public void setUp() {
    	ChromeOptions options = new ChromeOptions();
    	options.addArguments("--remote-allow-origins=*");
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
        driver = new ChromeDriver(options);
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumeg_pom\\src\\test\\resources\\login.html");
        loginPage = new LoginPage(driver);
    }

    @Test
    public void testLogin() {
        loginPage.enterUsername("admin");
        loginPage.enterPassword("password");
        loginPage.clickLogin();

        // Assuming a successful login redirects to the dashboard
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumeg_pom\\src\\test\\resources\\dashboard.html");
        dashboardPage = new DashboardPage(driver);
        assertEquals("Dashboard", dashboardPage.getDashboardTitle());
    }

    @AfterEach
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

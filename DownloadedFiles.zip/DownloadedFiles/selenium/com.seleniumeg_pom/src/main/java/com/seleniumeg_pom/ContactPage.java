package com.seleniumeg_pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ContactPage {
    private WebDriver driver;

    // Locators
    private By homeLink = By.id("homeLink");
    private By aboutLink = By.id("aboutLink");
    private By nameField = By.id("name");
    private By emailField = By.id("email");
    private By messageField = By.id("message");
    private By submitButton = By.id("submitButton");

    public ContactPage(WebDriver driver) {
        this.driver = driver;
    }

    // Action methods
    public HomePage goToHomePage() {
        driver.findElement(homeLink).click();
        return new HomePage(driver);
    }

    public AboutPage goToAboutPage() {
        driver.findElement(aboutLink).click();
        return new AboutPage(driver);
    }

    public void fillOutContactForm(String name, String email, String message) {
        driver.findElement(nameField).sendKeys(name);
        driver.findElement(emailField).sendKeys(email);
        driver.findElement(messageField).sendKeys(message);
        driver.findElement(submitButton).click();
    }
}


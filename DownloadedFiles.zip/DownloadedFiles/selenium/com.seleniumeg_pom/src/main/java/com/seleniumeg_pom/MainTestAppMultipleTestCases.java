package com.seleniumeg_pom;

import org.junit.jupiter.api.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

public class MainTestAppMultipleTestCases {
    private static WebDriver driver;
    private static WebDriverWait wait;

    @BeforeAll
    public static void setUp() {
        // Set up WebDriver and WebDriverWait
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));  // Wait for up to 10 seconds
    }

    @Test
    public void testSubscriptionForm() {
        // Navigate to the home page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumeg_pom\\src\\main\\resources\\Home.html");

        HomePage homePage = new HomePage(driver);

        // Test the subscription form interaction
        homePage.subscribeToNewsletter("test@example.com");

        // Assert that subscription was successful (you can check for a success message or similar element)
        WebElement successMessage = driver.findElement(By.id("rmessage"));
        assertTrue(successMessage.isDisplayed(), "You are susbcribed to News Letter");
    }

    @Test //new
    public void testNavigateToAboutPage() {
        // Navigate to the home page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumeg_pom\\src\\main\\resources\\Home.html");

        HomePage homePage = new HomePage(driver);

        // Navigate to About Page and verify the title
        AboutPage aboutPage = homePage.goToAboutPage();
        wait.until(ExpectedConditions.titleContains("About"));
        assertTrue(driver.getTitle().contains("About"), "The About page title should contain 'About'.");
    }
    
    @Test //new
    public void testNavigateToContactPage() {
        // Navigate to the home page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumeg_pom\\src\\main\\resources\\Home.html");

        HomePage homePage = new HomePage(driver);

        // Navigate to About Page first
        AboutPage aboutPage = homePage.goToAboutPage();
        wait.until(ExpectedConditions.titleContains("About"));

        // Then navigate to Contact Page and verify the title
        ContactPage contactPage = aboutPage.goToContactPage();
        wait.until(ExpectedConditions.titleContains("Contact"));
        assertTrue(driver.getTitle().contains("Contact"), "The Contact page title should contain 'Contact'.");
    }

    @Test
    public void testNavigateBackToHomePage() {
        // Navigate to the home page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumeg_pom\\src\\main\\resources\\Home.html");

        HomePage homePage = new HomePage(driver);

        // Navigate to About Page first
        AboutPage aboutPage = homePage.goToAboutPage();
        wait.until(ExpectedConditions.titleContains("About"));

        // Navigate to Contact Page next
        ContactPage contactPage = aboutPage.goToContactPage();
        wait.until(ExpectedConditions.titleContains("Contact"));

        // Then navigate back to Home Page and verify the title
        homePage = contactPage.goToHomePage();
        wait.until(ExpectedConditions.titleContains("Home"));
        assertTrue(driver.getTitle().contains("Home"), "The Home page title should contain 'Home'.");
    }

    /*
    @Test //old
    public void testNavigateBackToHomePage() {
        // Navigate to the home page
        driver.get("file:///C:/path/to/Home.html");

        HomePage homePage = new HomePage(driver);

        // Navigate to About Page first
        AboutPage aboutPage = homePage.goToAboutPage();
        wait.until(ExpectedConditions.titleContains("About"));

        // Navigate to Contact Page next
        ContactPage contactPage = aboutPage.goToContactPage();
        wait.until(ExpectedConditions.titleContains("Contact"));

        // Then navigate back to Home Page and verify the title
        homePage = contactPage.goToHomePage();
        wait.until(ExpectedConditions.titleContains("Home"));
        assertTrue(driver.getTitle().contains("Home"), "The Home page title should contain 'Home'.");
    }*/


    @Test
    public void testNavigation() {
        // Navigate to the home page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumeg_pom\\src\\main\\resources\\Home.html");

        HomePage homePage = new HomePage(driver);

        // Navigate to About Page and verify the title
        AboutPage aboutPage = homePage.goToAboutPage();
        wait.until(ExpectedConditions.titleContains("About"));
        assertTrue(driver.getTitle().contains("About"), "The About page title should contain 'About'.");

        // Navigate to Contact Page and verify the title
        ContactPage contactPage = aboutPage.goToContactPage();
        wait.until(ExpectedConditions.titleContains("Contact"));
        assertTrue(driver.getTitle().contains("Contact"), "The Contact page title should contain 'Contact'.");

        // Navigate back to Home Page and verify the title
        homePage = contactPage.goToHomePage();
        wait.until(ExpectedConditions.titleContains("Home"));
        assertTrue(driver.getTitle().contains("Home"), "The Home page title should contain 'Home'.");
    }

    @Test
    public void testContactForm() {
        // Navigate to the home page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumeg_pom\\src\\main\\resources\\Home.html");

        HomePage homePage = new HomePage(driver);

        // Navigate to About Page, then to Contact Page
        AboutPage aboutPage = homePage.goToAboutPage();
        ContactPage contactPage = aboutPage.goToContactPage();

        // Fill out the contact form
        contactPage.fillOutContactForm("John Doe", "johndoe@example.com", "This is a test message.");

        // Assert that the form was submitted successfully (check for a success message, confirmation, etc.)
        WebElement confirmationMessage = driver.findElement(By.id("rmessage"));
        assertTrue(confirmationMessage.isDisplayed(), "Mail Sent Successfully");
    }

    @AfterAll
    public static void tearDown() {
        // Quit the WebDriver after all tests are completed
        if (driver != null) {
            driver.quit();
        }
    }
}

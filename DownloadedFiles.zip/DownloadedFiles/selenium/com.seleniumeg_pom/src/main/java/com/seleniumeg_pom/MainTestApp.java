package com.seleniumeg_pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;


public class MainTestApp {
    private static WebDriver driver;

    @BeforeAll
    public static void setUp() {
        // Set the path to your chromedriver executable
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void testNavigationAndInteractions() {
        // Start at the home page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumeg_pom\\src\\main\\resources\\Home.html");

        HomePage homePage = new HomePage(driver);

        // Test subscription form interaction
        homePage.subscribeToNewsletter("test@example.com");

        // Test checkbox interaction
        homePage.acceptTermsAndConditions();

        // Navigate to About Page
        AboutPage aboutPage = homePage.goToAboutPage();
        assertTrue(driver.getTitle().contains("About"));

        // Show more information on the About page
        aboutPage.showMoreInfo();

        // Navigate to Contact Page
        ContactPage contactPage = aboutPage.goToContactPage();
        assertTrue(driver.getTitle().contains("Contact"));

        // Test contact form interaction
        contactPage.fillOutContactForm("John Doe", "johndoe@example.com", "This is a test message.");

        // Navigate back to Home Page
        homePage = contactPage.goToHomePage();
        assertTrue(driver.getTitle().contains("Home"));
    }

    @AfterAll
    public static void tearDown() {
        driver.quit();
    }
}


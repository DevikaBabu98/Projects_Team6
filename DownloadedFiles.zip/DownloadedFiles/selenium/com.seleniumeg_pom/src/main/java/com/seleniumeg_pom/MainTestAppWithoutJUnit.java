package com.seleniumeg_pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainTestAppWithoutJUnit {
    private WebDriver driver;

    public static void main(String[] args) {
    	MainTestAppWithoutJUnit test = new MainTestAppWithoutJUnit();
        test.setUp();
        test.testNavigationAndInteractions();
        test.tearDown();
    }

    public void setUp() {
        // Set the path to your chromedriver executable
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
        driver = new ChromeDriver();
    }

    public void testNavigationAndInteractions() {
        // Start at the home page
        driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\com.seleniumeg_pom\\src\\main\\resources\\Home.html");
        System.out.println("Navigated to Home Page");

        HomePage homePage = new HomePage(driver);

        // Test subscription form interaction
        homePage.subscribeToNewsletter("test@example.com");
        System.out.println("Subscribed with email: test@example.com");

        // Test checkbox interaction
        homePage.acceptTermsAndConditions();
        System.out.println("Accepted terms and conditions");

        // Navigate to About Page
        AboutPage aboutPage = homePage.goToAboutPage();
        String aboutTitle = driver.getTitle();
        if (aboutTitle.contains("About")) {
            System.out.println("Successfully navigated to About Page");
        } else {
            System.out.println("Failed to navigate to About Page");
        }

        // Show more information on the About page
        aboutPage.showMoreInfo();
        System.out.println("Displayed more information on About Page");

        // Navigate to Contact Page
        ContactPage contactPage = aboutPage.goToContactPage();
        String contactTitle = driver.getTitle();
        if (contactTitle.contains("Contact")) {
            System.out.println("Successfully navigated to Contact Page");
        } else {
            System.out.println("Failed to navigate to Contact Page");
        }

        // Test contact form interaction
        contactPage.fillOutContactForm("John Doe", "johndoe@example.com", "This is a test message.");
        System.out.println("Submitted contact form");

        // Navigate back to Home Page
        homePage = contactPage.goToHomePage();
        String homeTitle = driver.getTitle();
        if (homeTitle.contains("Home")) {
            System.out.println("Successfully navigated back to Home Page");
        } else {
            System.out.println("Failed to navigate back to Home Page");
        }

        // Navigate again to About Page
        aboutPage = homePage.goToAboutPage();
        aboutTitle = driver.getTitle();
        if (aboutTitle.contains("About")) {
            System.out.println("Successfully navigated to About Page again");
        } else {
            System.out.println("Failed to navigate to About Page again");
        }
    }

    public void tearDown() {
        // Close the browser after the test
        driver.quit();
        System.out.println("Test completed and browser closed");
    }
}

package com.seleniumeg_pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    private WebDriver driver;

    // Locators
    private By aboutLink = By.id("aboutLink");
    private By contactLink = By.id("contactLink");
    private By subscribeForm = By.id("subscribeForm");
    private By emailField = By.id("email");
    private By subscribeButton = By.id("subscribeButton");
    private By acceptTerms = By.id("acceptTerms");

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    // Action methods
    public AboutPage goToAboutPage() {
        driver.findElement(aboutLink).click();
        return new AboutPage(driver);
    }

    public ContactPage goToContactPage() {
        driver.findElement(contactLink).click();
        return new ContactPage(driver);
    }

    public void subscribeToNewsletter(String email) {
        driver.findElement(emailField).sendKeys(email);
        driver.findElement(subscribeButton).click();
    }

    public void acceptTermsAndConditions() {
        driver.findElement(acceptTerms).click();
    }
}

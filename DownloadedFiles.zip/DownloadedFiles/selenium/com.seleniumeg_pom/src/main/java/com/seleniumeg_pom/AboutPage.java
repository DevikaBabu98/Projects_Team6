package com.seleniumeg_pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AboutPage {
    private WebDriver driver;

    // Locators
    private By homeLink = By.id("homeLink");
    private By contactLink = By.id("contactLink");
    private By moreInfoButton = By.id("moreInfoButton");
    private By moreInfo = By.id("moreInfo");

    public AboutPage(WebDriver driver) {
        this.driver = driver;
    }

    // Action methods
    public HomePage goToHomePage() {
        driver.findElement(homeLink).click();
        return new HomePage(driver);
    }

    public ContactPage goToContactPage() {
        driver.findElement(contactLink).click();
        return new ContactPage(driver);
    }

    public void showMoreInfo() {
        driver.findElement(moreInfoButton).click();
        // Optionally, you can assert that more info is now visible
        driver.findElement(moreInfo).isDisplayed();
    }
}


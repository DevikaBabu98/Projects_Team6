package com.seleniumm;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByIdEg2 {

	public static void main(String[] args) throws Exception {
		//chrome driver path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
				
		//Create an instance of Chrome driver
		WebDriver driver = new ChromeDriver();
				
		//Load web page under Test
		driver.get("file:///D:\\GAMA Training\\PracticePrograms\\com.seleniumm\\src\\main\\resources\\LocateByIdEg2.html");
		
		//locate button element by id
		WebElement tbuttonField=driver.findElement(By.id("testButton"));
		
		Thread.sleep(3000);
		
		//click above button element
		tbuttonField.click();
		
		Thread.sleep(3000);
		
		//locate message element by id
		WebElement messageField=driver.findElement(By.id("message"));
		
		//get text in message element
		String umessage=messageField.getText();
		
		//display above text
		System.out.println("Updated Message:"+umessage);
		
		Thread.sleep(3000);
		
		driver.quit();
		
	}

}
